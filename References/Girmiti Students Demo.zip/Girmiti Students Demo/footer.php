<footer class="container-fluid text-center">
  <p>&copy; <?php echo date("Y"); ?>, Girmiti Students Demo</p>
</footer>

</body>
</html>
